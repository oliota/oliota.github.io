console.log("Se vc esta lendo essa mensagem é pq... vc me linkou corretamente")
console.log("Tente me achar no codigo conte dessa página, não será tão simples assim")