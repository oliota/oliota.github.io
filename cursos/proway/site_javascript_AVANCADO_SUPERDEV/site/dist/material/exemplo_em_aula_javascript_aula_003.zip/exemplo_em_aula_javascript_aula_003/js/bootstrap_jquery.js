document.writeln('<link rel="stylesheet" href="bootstrap/css/bootstrap.css">')
document.writeln('<script src="./bootstrap/js/bootstrap.bundle.js">'+'<'+"/script>")
document.writeln('<script src="./js/jquery.js">'+'<'+"/script>")
