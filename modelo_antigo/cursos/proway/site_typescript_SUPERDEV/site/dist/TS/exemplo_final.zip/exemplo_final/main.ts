import * as c from './classes.js';

var aluno= new c.Programador("Fulano",32);

aluno.escreveEmTela("Hello world");

var iniciante= new c.Javascript("Ciclano",32);

iniciante.escreveEmTela("Hello world");


var junin= new c.Jquery("Beltrano",32);

junin.escreveEmTela("Hello world");


var frontend= new c.Ajax("FrontEnder99",32);

frontend.escreveEmTela("Hello world");